import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import DeliveryPersonAxios from "../Axios/DeliveryPersonAxios.js"; // Import the axios instance

function DeliverPerson() {
  const [deliveryPersons, setDeliveryPersons] = useState([]);
  const [orderId, setOrderId] = useState(""); // Input for order ID
  const [showForm, setShowForm] = useState(false); // Manage the visibility of the form
  const [formData, setFormData] = useState({
    fname: "",
    lname: "",
    email: "",
    contactNo: "",
    address: "",
    password: "", // Added password field
  });

  useEffect(() => {
    const fetchDeliveryPersons = async () => {
      try {
        const response = await DeliveryPersonAxios.get("/api/admin/deliveryPersonList/4");
        setDeliveryPersons(response.data);
      } catch (error) {
        console.error("Error fetching delivery persons", error);
      }
    };

    fetchDeliveryPersons();
  }, []);

  // Function to remove a delivery person
  const handleRemove = async (id) => {
    try {
      await DeliveryPersonAxios.delete(`/api/admin/delivery/${id}`);
      setDeliveryPersons(deliveryPersons.filter((person) => person.userID !== id));
    } catch (error) {
      console.error("Error removing delivery person", error);
    }
  };

  // Function to handle form input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  // Function to add a new delivery person
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await DeliveryPersonAxios.post("/api/admin/add-delivery-person", formData);
      setShowForm(false);
      setFormData({ fname: "", lname: "", email: "", contactNo: "", address: "", password: "" });

      // Refresh the list
      const response = await DeliveryPersonAxios.get("/api/admin/deliveryPersonList/4");
      setDeliveryPersons(response.data);
    } catch (error) {
      console.error("Error adding delivery person", error);
    }
  };

  // Function to assign an order to a delivery person
  const handleAssignOrder = async (deliveryPersonId) => {
    if (!orderId) {
      alert("Please enter an Order ID.");
      return;
    }
  
    try {
      console.log(`Assigning Order ${orderId} to Delivery Person ${deliveryPersonId}`);
      
      const response = await DeliveryPersonAxios.put(`/api/admin/assign/${orderId}/${deliveryPersonId}`);
  
      console.log("Response:", response);
      alert(`Order ${orderId} assigned successfully to Delivery Person ${deliveryPersonId}`);
  
      setOrderId(""); // Clear the input field
    } catch (error) {
      console.error("Error assigning order:", error);
      
      // Check if there is an actual response from the backend
      if (error.response) {
        console.error("Response Data:", error.response.data);
        alert(`Error: ${error.response.data.message || "Failed to assign order"}`);
      } else {
        alert("Failed to assign order. Please check the server.");
      }
    }
  };
  

  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4">Delivery Person Management</h2>

      {/* Button to Show the Add Delivery Person Form */}
      <div className="mb-3 text-center">
        <button className="btn btn-success" onClick={() => setShowForm(true)}>
          Add Delivery Person
        </button>
      </div>

      {/* Form to Add Delivery Person */}
      {showForm && (
        <div className="mb-3">
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>First Name</label>
              <input
                type="text"
                name="fname"
                className="form-control"
                value={formData.fname}
                onChange={handleInputChange}
                required
              />
            </div>
            <div className="form-group">
              <label>Last Name</label>
              <input
                type="text"
                name="lname"
                className="form-control"
                value={formData.lname}
                onChange={handleInputChange}
                required
              />
            </div>
            <div className="form-group">
              <label>Email</label>
              <input
                type="email"
                name="email"
                className="form-control"
                value={formData.email}
                onChange={handleInputChange}
                required
              />
            </div>
            <div className="form-group">
              <label>Password</label>
              <input
                type="password"
                name="password"
                className="form-control"
                value={formData.password}
                onChange={handleInputChange}
                required
              />
            </div>
            <div className="form-group">
              <label>Contact No</label>
              <input
                type="text"
                name="contactNo"
                className="form-control"
                value={formData.contactNo}
                onChange={handleInputChange}
                required
              />
            </div>
            <div className="form-group">
              <label>Address</label>
              <textarea
                name="address"
                className="form-control"
                value={formData.address}
                onChange={handleInputChange}
                required
              />
            </div>
            <div className="form-group text-end">
              <button type="submit" className="btn btn-primary">Submit</button>
              <button type="button" className="btn btn-secondary ms-2" onClick={() => setShowForm(false)}>
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Input for Order ID */}
      <div className="mb-3">
        <label>Enter Order ID to Assign:</label>
        <input
          type="text"
          className="form-control"
          value={orderId}
          onChange={(e) => setOrderId(e.target.value)}
          placeholder="Enter Order ID"
        />
      </div>

      {/* Table to Display Delivery Persons */}
      <div className="table-responsive">
        <table className="table table-bordered table-hover">
          <thead className="thead-dark">
            <tr>
              <th>No</th>
              <th>Name</th>
              <th>Email</th>
              <th>Contact No</th>
              <th>Address</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {deliveryPersons.map((person, index) => (
              <tr key={person.userID}>
                <td>{index + 1}</td>
                <td>{`${person.fname} ${person.lname}`}</td>
                <td>{person.email}</td>
                <td>{person.contactNo}</td>
                <td>{person.address}</td>
                <td>
                  <button
                    className="btn btn-primary btn-sm me-2"
                    onClick={() => handleAssignOrder(person.userID)}
                  >
                    Assign Order
                  </button>
                  <button
                    className="btn btn-danger btn-sm"
                    onClick={() => handleRemove(person.userID)}
                  >
                    Remove
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default DeliverPerson;
